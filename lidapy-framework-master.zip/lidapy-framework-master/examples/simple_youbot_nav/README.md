##Running the example
Make sure ROS is installed and lidapy workspace is setup using the setup script. 
You can follow the instructions given in the [readme](https://github.com/CognitiveComputingResearchGroup/lidapy-framework/tree/master#lidapy-framework) file of lidapy-framework.

###Template
roslaunch [package-name] [launch-file-name]

Example:

    roslaunch simple_youbot_nav agent.launch
